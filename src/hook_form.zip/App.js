import './App.css';
import User from './components/User'



function App(){
  return (
    <div className="App">
      <h1>User Registration</h1>
      <User></User>
    </div>
  );
}

export default App;